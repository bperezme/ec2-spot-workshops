import json

from aws_cdk import (
    Stack,
    aws_iam as iam,
    aws_ec2 as ec2,
    CfnOutput
)

from constructs import Construct


class DevEnvStack(Stack):
    @staticmethod
    def __extract_instance_connect_ips():
        with open('assets/ip-ranges.json') as fd:
            ranges = json.load(fd)
            return [prefix['ip_prefix'] for prefix in ranges['prefixes'] if prefix['service'] == 'EC2_INSTANCE_CONNECT']

    def __create_vpc(self):
        return ec2.Vpc(
            self, "Vpc",
            vpc_name='DevEnvVPC',
            subnet_configuration=[
                ec2.SubnetConfiguration(
                    cidr_mask=24,
                    name="DevEnvVPCSubnetGroup",
                    subnet_type=ec2.SubnetType.PUBLIC
                )
            ]
        )

    def __create_security_group(self):
        sg = ec2.SecurityGroup(
            self, "DevEnvSecurityGroup",
            vpc=self.__vpc,
            security_group_name="DevEnvSecurityGroup",
        )

        for ip in self.__extract_instance_connect_ips():
            sg.add_ingress_rule(
                peer=ec2.Peer.ipv4(ip),
                connection=ec2.Port.tcp(22)
            )

        return sg

    def __create_instance(self):
        with open('assets/user_data_scripts/ecs_instance_draining.txt') as fd:
            user_data = fd.read()

        instance = ec2.Instance(
            self, 'DevEnvironment',
            vpc=self.__vpc,
            instance_name='DevelopmentEnvironment',
            instance_type=ec2.InstanceType('t2.micro'),
            user_data=ec2.UserData.custom(user_data),
            machine_image=ec2.MachineImage.latest_amazon_linux2(),
            security_group=self.__sg
        )

        instance.add_to_role_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                resources=['*'],
                actions=[
                    "batch:DescribeJobQueues",
                    "batch:CreateComputeEnvironment",
                    "batch:DeleteComputeEnvironment",
                    "batch:SubmitJob",
                    "batch:UpdateComputeEnvironment",
                    "batch:ListJobs",
                    "batch:DescribeComputeEnvironments",
                    "batch:DeregisterJobDefinition",
                    "batch:CreateJobQueue",
                    "batch:DescribeJobs",
                    "batch:RegisterJobDefinition",
                    "batch:DescribeJobDefinitions",
                    "batch:DeleteJobQueue",
                    "batch:UpdateJobQueue",
                    "cloudformation:DescribeStacks",
                    "ecr:*",
                    "iam:PassRole",
                    "s3:DeleteObject",
                    "s3:ListBucket",
                    "s3:PutObject",
                    "states:StartExecution",
                ]
            )
        )

        return instance

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        self.__vpc = self.__create_vpc()
        self.__sg = self.__create_security_group()
        instance = self.__create_instance()

        CfnOutput(
            self, 'DevEnvironmentConnectionURL',
            value=f'https://{self.region}.console.aws.amazon.com/ec2-instance-connect/ssh?region={self.region}&connType=standard&instanceId={instance.instance_id}&osUser=ec2-user&sshPort=22'
        )
