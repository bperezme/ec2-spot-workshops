import aws_cdk as cdk

from stacks import PipelineStack, DevEnvStack


app = cdk.App()

PipelineStack(app, "RenderingWithBatch-Pipeline")
DevEnvStack(app, 'RenderingWithBatch-DevEnv')

app.synth()
