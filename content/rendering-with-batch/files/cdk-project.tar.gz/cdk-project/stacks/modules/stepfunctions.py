from aws_cdk import (
    aws_stepfunctions as stepfunctions,
    aws_iam as iam,
    Duration,
    NestedStack,
)

from constructs import Construct


class StepFunctionsModule(NestedStack):
    def __create_state_machine(self, preprocessing_func):
        with open('assets/state_machine_definition.json') as fd:
            definition = fd.read()

        definition = definition.replace('{{ FUNCTION_ARN }}', preprocessing_func.function_arn)

        state_machine = stepfunctions.StateMachine(
            self, 'StateMachine',
            definition_body=stepfunctions.DefinitionBody.from_string(definition),
            timeout=Duration.days(1)
        )

        state_machine.add_to_role_policy(
            iam.PolicyStatement(
                actions=[
                    'events:PutTargets',
                    'events:PutRule',
                    'events:DescribeRule',
                    'batch:SubmitJob'
                ],
                resources=['*'],
                effect=iam.Effect.ALLOW
            )
        )

        preprocessing_func.grant_invoke(state_machine)

        return state_machine

    def __init__(self, scope: Construct, construct_id: str, preprocessing_func, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        self.state_machine = self.__create_state_machine(preprocessing_func)
