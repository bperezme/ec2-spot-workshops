from aws_cdk import (
    Stack,
    aws_iam as iam
)

from constructs import Construct
from cdk_use_cases.custom_cloud9_ssm import CustomCloud9Ssm


class C9EnvStack(Stack):
    __PROJECT_URL = 'https://raw.githubusercontent.com/bpguasch/ec2-spot-workshops/blender_rendering_using_batch/content/rendering-with-batch/files/cdk-project.tar.gz'

    def __create_environment(self):
        env = CustomCloud9Ssm(self, 'CustomCloud9Ssm')

        env.ec2_role.add_to_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                resources=['*'],
                actions=[
                    "batch:DescribeJobQueues",
                    "batch:CreateComputeEnvironment",
                    "batch:DeleteComputeEnvironment",
                    "batch:SubmitJob",
                    "batch:UpdateComputeEnvironment",
                    "batch:ListJobs",
                    "batch:DescribeComputeEnvironments",
                    "batch:DeregisterJobDefinition",
                    "batch:CreateJobQueue",
                    "batch:DescribeJobs",
                    "batch:RegisterJobDefinition",
                    "batch:DescribeJobDefinitions",
                    "batch:DeleteJobQueue",
                    "batch:UpdateJobQueue",
                    "cloudformation:DescribeStacks",
                    "s3:PutObject",
                    "s3:ListBucket",
                    "s3:DeleteObject",
                    "ecr:*",
                    "states:StartExecution",
                    "iam:PassRole"
                ]
            )
        )

        # Add a step in SSM doc that deploys the CDK project with all the resources
        env.deploy_cdk_project(self.__PROJECT_URL)

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        self.__create_environment()
